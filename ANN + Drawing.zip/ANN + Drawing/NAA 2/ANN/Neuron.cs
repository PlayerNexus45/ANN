﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ANN
{
    internal class Neuron
    {
        public double value;
        public double error;
    }
}
