using System.Diagnostics;

namespace ANN
{
    public partial class Form1 : Form
    {
        List<ONEPIECE> onepieces = new();
        int counter = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StreamReader sr = new("digits.csv");
            string s;
            
            while (!sr.EndOfStream)
            {
                s = sr.ReadLine();
                string[] numbers = s.Split(',');
                ONEPIECE onepiece = new ONEPIECE(numbers);
                onepieces.Add(onepiece);
            }
            sr.Close();
            pictureBox1.Invalidate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            counter--;
            pictureBox1.Invalidate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            counter++;
            pictureBox1.Invalidate();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            if (onepieces.Count != 0)
            {
                onepieces[counter].Draw(g);
                label1.Text = onepieces[counter].digit.ToString();
            }

        }
    }
}