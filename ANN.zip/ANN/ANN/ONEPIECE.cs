﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ANN
{
    internal class ONEPIECE
    {
        //Can we get much higher
        // so hiiig
        // oh oh oh
        //ohoohoh
        public int digit;

        int[,] image = new int[28, 28];

        public ONEPIECE(string[] numbers)
        {
            this.digit = Convert.ToInt16(numbers[0]);
            for (int i = 1; i < numbers.Length; i++)
            {
                int x = (i - 1) % 28;
                int y = (i - 1) / 28;

                image[x, y] = Convert.ToInt16(numbers[i]);
            }
        }
        public void Draw(Graphics g)
        {
            for (int i = 0; i < 28; i++)
            {
                for (int j = 0; j < 28; j++)
                {
                    SolidBrush b = new SolidBrush(Color.FromArgb(image[i, j], image[i, j], image[i, j]));
                    g.FillRectangle(b, i*10, j*10, 10, 10);
                }
            }
        }
    }
}
