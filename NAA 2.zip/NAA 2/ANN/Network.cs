﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ANN
{
    //As the darkness of night falls around my sword
    //the hunter within looses control
    //gotta let it out
    //gotta let it out
    internal class Network
    {
        public int layers { get; set; }
        public Neuron[][] Neurons { get; set; }
        public double[][][] Weights { get; set; }

        public Network(int[] numberOfNeurons)
        {
            layers = numberOfNeurons.Length;
            Neurons = new Neuron[layers][];
            Weights = new double[layers - 1][][];

            for (int i = 0; i < layers; i++)
            {
                Neurons[i] = new Neuron[numberOfNeurons[i]];
                for (int j = 0; j < numberOfNeurons[i]; j++)
                {
                    Neurons[i][j] = new Neuron();
                }

                if (i < layers - 1)
                {
                    Weights[i] = new double[numberOfNeurons[i]][];
                    for (int j = 0; j < numberOfNeurons[i]; j++)
                    {
                        Weights[i][j] = new double[numberOfNeurons[i + 1]];
                    }
                }
            }
        }

        public void SetRandomWeights()
        {
            Random rnd = new Random();
            for (int i = 0; i < layers - 1; i++)
            {
                for (int j = 0; j < Neurons[i].Length; j++)
                {
                    for (int k = 0; k < Weights[i][j].Length; k++)
                    {
                        Weights[i][j][k] = rnd.Next(-100000, 100000) * 0.00001;
                    }
                }
            }
        }

        public void SetInputs(double[] values)
        {
            for (int i = 0; i < values.Length; i++)
            {
                Neurons[0][i].value = values[i];
            }
        }

        public static double Sigmoid(double x)
        {
            return 1.0 / (1 + Math.Exp(-x));
        }

        public void ForwardProcess()
        {
            for (int i = 1; i < layers; i++)
            {
                for (int j = 0; j < Neurons[i].Length; j++)
                {
                    double sum = 0;

                    for (int k = 0; k < Neurons[i - 1].Length; k++)
                    {
                        sum += Neurons[i - 1][k].value * Weights[i - 1][k][j];  
                    }
                    double val = Sigmoid(sum);
                    Neurons[i][j].value = val;

                }
            }
        }
        public void BackPropagation(int trueValue)
        {
            for (int i = 0; i < Neurons[layers -1].Length; i++)
            {
                Neurons[layers - 1][i].error = (i == trueValue ? 1 : 0) - Neurons[layers - 1][i].value;
            }
            for (int i = layers-2; i > 0; i--)
            {
                for (int j = 0; j < Neurons[i].Length; j++)
                {
                    Neurons[i][j].error = 0;
                    for (int k = 0; k < Neurons[i + 1].Length; k++)
                    {
                        Neurons[i][j].error += Neurons[i + 1][k].error * Weights[i][j][k];
                    }
                }
            }
            for (int i = 0; i < layers - 1; i++)
            {
                for (int j = 0; j < Neurons[i].Length-1; j++)
                {
                    for (int k = 0; k < Weights[i][j].Length; k++)
                    {
                        Weights[i][j][k] += 0.01 * Neurons[i][j].value * Neurons[i + 1][j].error * Neurons[i + 1][j].value * (1- Neurons[i + 1][j].value);
                    }
                }
            }
        }

        public double[] Output()
        {
            double[] outputs = new double[Neurons[layers - 1].Length];
            for (int i = 0; i < Neurons[layers - 1].Length; i++)
            {
                outputs[i] = Neurons[layers - 1][i].value;
            }
            return outputs;
        }
    }

}
