namespace ANN
{
    public partial class Form1 : Form
    {
        List<ONEPIECE> onepieces = new();
        int counter = 0;
        Network network;
        public Form1()
        {
            InitializeComponent();
            network = new(new int[3] {784, 100, 10 });
            network.SetRandomWeights();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            StreamReader sr = new("digits.csv");
            string s;

            while (!sr.EndOfStream)
            {
                s = sr.ReadLine();
                string[] numbers = s.Split(',');
                ONEPIECE onepiece = new ONEPIECE(numbers);
                onepieces.Add(onepiece);
            }
            sr.Close();
            pictureBox1.Invalidate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            counter--;
            pictureBox1.Invalidate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            counter++;
            pictureBox1.Invalidate();
        }
        private int maxIndex(double[] l)
        {
            int mI = 0;
            for (int i = 1; i < l.Length; i++)
            {
                if (l[mI] < l[i])
                {
                    mI = i;
                }
            }
            return mI;
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            if (onepieces.Count != 0)
            {
                double[] inputs = new double[28 * 28];
                double[] outputs = new double[10];
                string outtext = "";
                onepieces[counter].Draw(g);
                int trueVal = onepieces[counter].digit;
                label1.Text = trueVal.ToString();
                for (int i = 0; i < 28; i++)
                {
                    for (int j = 0; j < 28; j++)
                    {
                        inputs[i * 28 + j] = onepieces[counter].image[i, j]/255f;
                    }

                }
                //double[] i1 = new double[2] { 0.1, 0.9 };
                network.SetInputs(inputs);
                network.ForwardProcess();
                network.BackPropagation(trueVal);
                outputs = network.Output();
                int mI = maxIndex(outputs);
                for (int i = 0; i < 10; i++)
                {
                    if (mI == i)
                    {
                        outtext += " * ";
                    }
                    outtext += i.ToString() + ": " + outputs[i].ToString() + "\n";
                }
                label2.Text = outtext;
            }
        }

    }
}