﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ANN
{

    internal class Network
    {
        public int layers { get; set; }
        public Neuron[][] Neurons { get; set; }
        public double[][][] Weights { get; set; }

        public Network(int[] numberOfNeurons)
        {
            layers = numberOfNeurons.Length;
            Neurons = new Neuron[layers][];
            Weights = new double[layers - 1][][];

            for (int i = 0; i < layers; i++)
            {
                Neurons[i] = new Neuron[numberOfNeurons[i]];
                for (int j = 0; j < numberOfNeurons[i]; j++)
                {
                    Neurons[i][j] = new Neuron();
                }

                if (i < layers - 1)
                {
                    Weights[i] = new double[numberOfNeurons[i]][];
                    for (int j = 0; j < numberOfNeurons[i]; j++)
                    {
                        Weights[i][j] = new double[numberOfNeurons[i + 1]];
                    }
                }
            }
        }

        public void SetRandomWeights()
        {
            Random rnd = new Random();
            for (int i = 0; i < layers - 1; i++)
            {
                for (int j = 0; j < Neurons[i].Length; j++)
                {
                    for (int k = 0; k < Weights[i][j].Length; k++)
                    {
                        Weights[i][j][k] = rnd.Next(-100000, 100000) * 0.00001;
                    }
                }
            }
        }

        public void SetInputs(double[] values)
        {
            for (int i = 0; i < values.Length; i++)
            {
                Neurons[0][i].value = values[i];
            }
        }

        public static double Sigmoid(double x)
        {
            return 1.0 / (1 + Math.Exp(-x));
        }

        public void ForwardProcess()
        {
            for (int i = 1; i < layers; i++)
            {
                for (int j = 0; j < Neurons[i].Length; j++)
                {
                    double sum = 0;

                    for (int k = 0; k < Neurons[i - 1].Length; k++)
                    {
                        sum += Neurons[i - 1][k].value * Weights[i - 1][k][j];  
                    }
                    double val = Sigmoid(sum);
                    Neurons[i][j].value = val;

                }
            }
        }
        public void BackwardProcess(double expected, double learningRate)
        {
            for (int i = 0; i < Neurons[layers - 1].Length; i++)
            {
                double output = Neurons[layers - 1][i].value;
                Neurons[layers - 1][i].error = (i == expected ? 1 : 0) - Neurons[layers - 1][i].value;
            }
            for (int i = layers - 2; i >= 1; i--)
            {
                for (int j = 0; j < Neurons[i].Length; j++)
                {
                    double sum = 0;

                    for (int k = 0; k < Neurons[i + 1].Length; k++)
                    {
                        sum += Weights[i][j][k] * Neurons[i + 1][k].error;
                    }

                    Neurons[i][j].error = sum;
                }
            }
            for (int i = 0; i < layers - 1; i++)
            {
                for (int j = 0; j < Neurons[i].Length; j++)
                {
                    for (int k = 0; k < Neurons[i + 1].Length; k++)
                    {
                        double output = Neurons[i][j].value;
                        double error = Neurons[i + 1][k].error;
                        double delta = learningRate * output * error * Neurons[i + 1][k].value * (1 - Neurons[i + 1][k].value);
                        Weights[i][j][k] += delta;
                    }
                }
            }
        }
        public void Save(string pathToFile)
        {
            StreamWriter sw = new(pathToFile);
            sw.Flush();
            string toWrite = "";
            for (int i = 0; i < layers - 1; i++)
            {
                for (int j = 0; j < Neurons[i].Length; j++)
                {
                    for (int k = 0; k < Weights[i][j].Length; k++)
                    {
                        toWrite += Weights[i][j][k].ToString() + ' ';
                    }
                }
            }
            sw.WriteLine(toWrite);
            toWrite = "";
            for (int i = 0; i < layers - 1; i++)
            {
                for (int j = 0; j < Neurons[i].Length; j++)
                {
                    toWrite += Neurons[i][j].error.ToString() + ' ';
                }
            }
            sw.WriteLine(toWrite);
            sw.Close();

        }
        public void Load(string pathToFile)
        {
            StreamReader sr = new StreamReader(pathToFile);
            string[] lines = sr.ReadToEnd().Split('\n');
            string[] weightValues = lines[0].Split(' ');
            string[] errorValues = lines[1].Split(' ');

            int weightIndex = 0;
            for (int i = 0; i < layers - 1; i++)
            {
                for (int j = 0; j < Neurons[i].Length; j++)
                {
                    for (int k = 0; k < Weights[i][j].Length; k++)
                    {
                        Weights[i][j][k] = double.Parse(weightValues[weightIndex]);
                        weightIndex++;
                    }
                }
            }
            int errorIndex = 0;
            for (int i = 0; i < layers - 1; i++)
            {
                for (int j = 0; j < Neurons[i].Length; j++)
                {
                    Neurons[i][j].error = double.Parse(errorValues[errorIndex]);
                    errorIndex++;
                }
            }

            sr.Close();
        }



        public double[] Output()
        {
            double[] outputs = new double[Neurons[layers - 1].Length];
            for (int i = 0; i < Neurons[layers - 1].Length; i++)
            {
                outputs[i] = Neurons[layers - 1][i].value;
            }
            return outputs;
        }
    }

}
