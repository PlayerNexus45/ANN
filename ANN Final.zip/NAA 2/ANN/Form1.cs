namespace ANN
{
    public partial class Form1 : Form
    {
        List<ONEPIECE> onepieces = new();
        int counter = 0;
        bool learnMode = false;
        int dataCount;
        Network network;
        public Form1()
        {
            InitializeComponent();
            network = new(new int[3] { 784, 100, 10 });
            if (!File.Exists("savedValues.txt"))
            {
                StreamWriter sr = File.CreateText("savedValues.txt");
                sr.Close();
            }
            network.SetRandomWeights();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            StreamReader sr = new("onepieces.csv");
            string s;
            s = sr.ReadLine();
            while (!sr.EndOfStream)
            {
                s = sr.ReadLine();
                string[] numbers = s.Split(',');
                ONEPIECE onepiece = new ONEPIECE(numbers);
                onepieces.Add(onepiece);
            }
            sr.Close();
            dataCount = onepieces.Count;
            pictureBox1.Invalidate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            counter--;
            pictureBox1.Invalidate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            counter++;
            pictureBox1.Invalidate();
        }
        private int maxIndex(double[] l)
        {
            int mI = 0;
            for (int i = 1; i < l.Length; i++)
            {
                if (l[mI] < l[i])
                {
                    mI = i;
                }
            }
            return mI;
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            if (onepieces.Count != 0)
            {
                double[] inputs = new double[28 * 28];
                double[] outputs = new double[10];
                string outtext = "";
                counter = (counter == dataCount ? 0 : counter);
                counter = Math.Clamp(counter, 0, dataCount);
                onepieces[counter].Draw(g);
                int trueVal = onepieces[counter].digit;
                label1.Text = trueVal.ToString();
                for (int i = 0; i < 28; i++)
                {
                    for (int j = 0; j < 28; j++)
                    {
                        inputs[i * 28 + j] = onepieces[counter].image[i, j] / 255f;
                    }

                }
                //double[] i1 = new double[2] { 0.1, 0.9 };
                network.SetInputs(inputs);
                network.ForwardProcess();

                outputs = network.Output();
                int mI = maxIndex(outputs);

                for (int i = 0; i < 10; i++)
                {
                    if (mI == i)
                    {
                        outtext += " * ";
                    }
                    outtext += i.ToString() + ": " + outputs[i].ToString() + "\n";
                }

                label2.Text = outtext;
                network.BackwardProcess(trueVal, 0.03);
                if (mI == trueVal)
                {
                    this.BackColor = Color.Green;
                }
                else
                {
                    this.BackColor = Color.Red;
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            counter++;
            pictureBox1.Invalidate();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //learnMode = !learnMode;
            //label1.Visible = !learnMode;
            //label2.Visible = !learnMode;
            //pictureBox1.Visible = !learnMode;
            //button2.Visible = !learnMode;
            //button3.Visible = !learnMode;
            timer1.Interval = 1;
            timer1.Enabled = !timer1.Enabled;


        }

        private void button5_Click(object sender, EventArgs e)
        {
            network.Save("savedValues.txt");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            network.Load("savedValues.txt");
        }
    }
}